<?php
	// Remove custom tables from Database
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$slider_tble = $wpdb->prefix."slider_tble";
	$sql = "DROP TABLE IF EXISTS $slider_tble";
	$wpdb->query($sql);
	
?>