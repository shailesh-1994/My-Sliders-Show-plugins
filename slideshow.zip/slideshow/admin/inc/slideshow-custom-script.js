	$ = jQuery;
	var ajax_url = '../wp-admin/admin-ajax.php';

	$(document).ready(function ($){
		auto_hide_alerts();

		// Apply DataTable to 
		$('#slidershow_table').DataTable({
			"order": [[ 1, "asc" ]]
		});
		$('#device_model_table').DataTable({    
			rowReorder: {
				selector: 'tr'
			},
		});

		$(".remove_sorting").removeClass("sorting, sorting_asc");

		$("input[name='all_device_del']").on("click",function () {
			$("td.del-device-check input[type='checkbox']").attr('checked', this.checked);
		});
		$(".del-device-btn").click(function(){
			var id = [];
			$('.del-device-check :checkbox:checked').each(function(i){
				id[i] = $(this).val();
			});
			if(id.length === 0) {
				alert("Please Select atleast one checkbox");
			} else {
				$.ajax({
					method: "POST",
					type: "jsonp",
					url: ajax_url,
					data: {'id':id, action: 'delete_multiple_device'},
					success: function(data) {
						$('.wrap').prepend('<div class="notice notice-success is-dismissible"><p> Device deleted successfully </p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
						$("#slidershow_table").load(' #slidershow_table > *');
						auto_hide_alerts();
					}
				});
			}
		});

		// Delete Model Type
		$("input[name='all_model_del']").on("click",function () {
			$("td.model-check input[type='checkbox']").attr('checked', this.checked);
		});
		$(".del-model-btn").click(function(){
			var id = [];
			$('.model-check :checkbox:checked').each(function(i){
				id[i] = $(this).val();
			});

			if(id.length === 0) {
				alert("Please Select atleast one checkbox");
			} else {
				$.ajax({
					method: "POST",
					type: "jsonp",
					url: ajax_url,
					data: {'id':id, action: 'delete_multiple_model'},
					success: function(data) {
						$('.wrap').prepend('<div class="notice notice-success is-dismissible"><p> Device model deleted successfully </p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
						$("#device_model_table").load(' #device_model_table > *');
						auto_hide_alerts();
					}
				});
			}
		});
	});

	// Hide Pop-up function
	function hidePopup(){
		$(".popup-wrapper, .popup-overlay").hide();
		$('body').removeClass('modal-open');
	}

	// Get image URL
	function image_url(id){
		if(id){
			var str = '&action=sqw_image_url&id='+id;
			$.ajax({
				type: "POST",
				dataType: "html",
				url: ajax_url,
				data: str,
				success: function(data){
					if(data){
						$('#image-preview').attr('src',data);
					}
				},
				error: function(jqXHR, textStatus, errorThrown){
					console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
				}
			});
		}
	}

	// Delete Function
	function sqw_remove(tbl,id, model_id = ''){
		
		if ( tbl == 'slider_tble'){
			var message = "this device type?";
		}
		var result = confirm("Do you want to delete " + message );
		if(result){
			var redirect = '';
			if(tbl == 'slider_tble') {
				redirectTo = 'admin.php?page=sqw_device_type&deleted';
			} 
			var str = '&action=sqw_remove&tbl='+tbl+'&id='+id;
			$.ajax({
				type: "POST",
				dataType: "html",
				url: ajax_url,
				data: str,
				success: function(data){
					if(data == 1){
						window.location.replace(redirectTo);
					} else {
						alert('Issue, Please Try After Some Time');
					}
				},
				error: function(jqXHR, textStatus, errorThrown){
					console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
				}
			});
		}
	}

	function auto_hide_alerts() {
		window.setTimeout(function () { 
			$(".notice-success").remove(); 
		}, 3000);
	}

	$(document).on('keypress', 'input[type="search"]',function(event) {
		var key = event.keyCode;
		if (key === 32) {
			event.preventDefault();
		}
	});

	$(document).ready(function() {  
		var fixHelper = function(e, ui) {
			ui.children().each(function() {
				$(this).width($(this).width());
			});
			return ui;
		};
	  $('table#slidershow_table tbody').sortable({   
		 delay: 150,
		 stop: function() {
				var selectedData = new Array();
				$('tbody > tr').each(function() {
					selectedData.push({
						id: $(this).attr('id'),                        
					});
				});
		  var table_name =  $(this).parent().attr('id');      
			   jQuery.ajax({ 
					url:ajax_url,
					type: 'post',  
					dataType: 'json',                 
					data: {
						position: selectedData, 
						action:'change_order' ,
						table_name: table_name,                  
					},
					success : function(response) {
						if ( response.status == true ) {
							jGrowlAlert("Re-Arrange successfully", 'success');
						} else {
							// jGrowlAlert("Please try again", 'error');
						}
					}
				 });
			}
		});
	});

