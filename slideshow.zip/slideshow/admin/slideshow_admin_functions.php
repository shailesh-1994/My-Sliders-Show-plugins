<?php
/* ----- Admin Page & Menu Section ----- */
/**
 * Plugin Menu For Sidekick Quote Plug-in Options
 * @return create a new page at admin side for all options
 */
add_action('admin_menu','sqw_plugin_menu');
function sqw_plugin_menu() {
    add_menu_page('slideshow', 'Slideshow', 'manage_options', 'sqw_device_type', 'slideshow_function', 'dashicons-text-page', 20);
}
function slideshow_function() {
   include 'slideshow_page.php';
}

add_action('admin_footer', 'admin_conditional_css');
function admin_conditional_css() {
    if(isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'sqw_add_device_model') {
?>
<script type="text/javascript">
    $('#toplevel_page_sqw_option ul.wp-submenu li:nth-child(4)').addClass('current');
    $('#toplevel_page_sqw_option ul.wp-submenu li:nth-child(4) a').addClass('current');
</script>
<?php
    }
}

/**
 * function for get image URL from attachment id
 * @author KK
 * @param int : attachment id
 * @return string : Image URL
 */
add_action('wp_ajax_sqw_image_url', 'sqw_image_url');
add_action('wp_ajax_nopriv_sqw_image_url', 'sqw_image_url');
function sqw_image_url(){
    $id = $_POST['id'];
    if( !empty($id) ){
        echo wp_get_attachment_url($id);
    } else {
        echo 0;
    }
    die();
}

/**
 * function for delete data from database.
*/
add_action('wp_ajax_nopriv_sqw_remove', 'sqw_remove');
add_action('wp_ajax_sqw_remove', 'sqw_remove');
function sqw_remove() {
    global $wpdb;
    $id = $_POST['id'];
    $tbl_name = $_POST['tbl'];
    $wp_tbl_name = $wpdb->prefix.$_POST['tbl'];

    if(!empty($id) && !empty($tbl_name)) {
        if($tbl_name == 'sqw_device_model') {
            $issue_types = $wpdb->prefix."sqw_issue_types";
            $wpdb->query("DELETE FROM $issue_types WHERE model_id = $id;");
        }
        echo $wpdb->query("DELETE FROM $wp_tbl_name WHERE id = $id;");
    } else {
        echo 0;
    }
    die();
}

// Delete record of device type
add_action('wp_ajax_delete_multiple_device','delete_multiple_device');
add_action('wp_ajax_nopriv_delete_multiple_device','delete_multiple_device');
function delete_multiple_device(){
    global $wpdb;
    $slider_tble = $wpdb->prefix."slider_tble";

    if( !empty($_POST["id"]) ) {
        foreach($_POST["id"] as $id) {
            $wpdb->query("DELETE FROM $slider_tble WHERE id = '".$id."'");
        }
    }
    die();
}

function upload_file_by_url( $image_url ) {
    require_once( ABSPATH . 'wp-admin/includes/file.php' );
    $temp_file = download_url( $image_url );

    if( is_wp_error( $temp_file ) ) {
        return false;
    }

    $file = array(
        'name'     => basename( $image_url ),
        'type'     => mime_content_type( $temp_file ),
        'tmp_name' => $temp_file,
        'size'     => filesize( $temp_file ),
    );
    $sideload = wp_handle_sideload(
        $file,
        array(
            'test_form'   => false
        )
    );

    if( ! empty( $sideload[ 'error' ] ) ) {
        return false;
    }

    $attachment_id = wp_insert_attachment(
        array(
            'guid'           => $sideload[ 'url' ],
            'post_mime_type' => $sideload[ 'type' ],
            'post_title'     => basename( $sideload[ 'file' ] ),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ),
        $sideload[ 'file' ]
    );

    if( is_wp_error( $attachment_id ) || ! $attachment_id ) {
        return false;
    }

    require_once( ABSPATH . 'wp-admin/includes/image.php' );
    wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata( $attachment_id, $sideload[ 'file' ] ));
    return $attachment_id;
}
?>