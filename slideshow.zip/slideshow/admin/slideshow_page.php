		<?php
			global $wpdb;
			wp_enqueue_media();
			$slider_tble = $wpdb->prefix."slider_tble";
			$csql = "SELECT * FROM $slider_tble ORDER BY `type_position` ASC;";
			$cresult = $wpdb->get_results($csql);
		?>
		<div class="sqw_wraper">
			<h1> Slideshow </h1><hr/>
			<button class="button button-primary"  onclick="open_popup()"> Add Slide </button>
			<?php if(count($cresult) != 0) { ?>
			<button class="button button-primary button-delete del-device-btn"> Delete Slide </button>
			<?php } ?>
			<div class="wrap">
			<?php
				if(isset($_POST['btn_type_submit'])) {
					$error       = false;
					$error_arr   = array();
					$action      = $_POST['device_type_action'];
					$slider_id   = $_POST['slider_id'];
					$name        = $_POST['type_name'];
					$timage      = $_POST['type_image'];
					
					
					if(!isset($timage) || empty($timage)) {
						$error = true;
						array_push($error_arr, 'Image is required');
					}
					if($error == false) {
						if ( !empty($action) && $action == "device_type_add" ) {
							$tiresult = $wpdb->query("INSERT INTO $slider_tble (name,image,status) VALUES('".$name."','".$timage."', '1')");
							if( $tiresult == 1 ){
								$url = admin_url('admin.php?page=sqw_device_type&added');
								echo '<script>window.location="'.$url.'";</script>';
							}
						} else if( $action == "device_type_edit" ){
							$turesult = $wpdb->query("UPDATE $slider_tble SET name = '".$name."', image = '".$timage."' WHERE id = $slider_id");
							if( $turesult == 1 ){
								$url = admin_url('admin.php?page=sqw_device_type&updated');
								echo '<script>window.location="'.$url.'";</script>';
							}
						}
					} else {
						show_errors($error_arr);
					}
				} else {
					if(isset($_GET['deleted'])) {
						echo '<div class="notice notice-success is-dismissible"><p> Slider deleted successfully </p></div>';
					} else if(isset($_GET['added'])) {
						echo '<div class="notice notice-success is-dismissible"><p> Slider added successfully </p></div>';
					} else if(isset($_GET['updated'])) {
						echo '<div class="notice notice-success is-dismissible"><p> Slider updated successfully </p></div>';
					}
				}
			?>
				<div id="device-popup" class="popup-overlay">
					<div class="sqw_form_wraper popup-wrapper">
						<div class="popup-header button-primary">
							<h3 class="popup-title">Add Slider</h3>
							<a class="close" onclick="hidePopup()">&times;</a>
						</div>
						<form name="slider_form" id="slider_form" action="#" method="post" enctype="multipart/form-data ">
							<input type="hidden" name="slider_id" id="slider_id" value="">
							<div class="popup-body">
							   <label>Select Image</label>
								<div class="image-section">
									<input id="upload_image_button" type="button" class="button" value="<?php _e( 'Upload image' ); ?>" required/>
									<input type="hidden" name="type_image" id="image_attachment_id" value="">
									<div class="image-preview-wrapper"><img id="image-preview" src=""></div>
								</div>
							</div>
							<div class="popup-footer">
								<input type="submit" name="btn_type_submit" id="btn_type_submit" class="button button-primary" value="Add Device">
								<input type="hidden" name="device_type_action" id="device_type_action" value="device_type_add">
							</div>
						</form>
					</div>
				</div>
			</div>

			<!-- Device Type Table -->
			<?php
				if($cresult) {
			?>
			<table id="slidershow_table" class="sqw_table">
				<thead>
					<tr>
						<th class="all_device_del"><input type="checkbox" name="all_device_del"></th>
						<th> # </th>
						<th> Image </th>
						<th> Action </th>
					</tr>
				</thead>

				<tbody>
				<?php
					$i = 1;
					foreach ($cresult as $cvalue) {
						$slider_id = $cvalue->id;

						if(isset($cvalue->image) && !empty($cvalue->image)) {
							$imageExist = wp_get_attachment_metadata($cvalue->image);

							if(isset($imageExist) && !empty($imageExist)) {
								$url = wp_get_attachment_url($cvalue->image);

								if(!empty($url)) {
									$url = $url;
								} else {
									$url = SQW_PLUGIN_PLACEHOLDER_IMAGE_URL;
								}
							} else {
								$url = SQW_PLUGIN_PLACEHOLDER_IMAGE_URL;
							}
						} else {
							$url = SQW_PLUGIN_PLACEHOLDER_IMAGE_URL;
						}
				?>
					<tr id="<?php echo $slider_id; ?>">
						<td class="del-device-check"><input type="checkbox" class="del-check-device" name="device_del[]" value="<?php echo $slider_id; ?>"></td>
						<td><?php echo $i; ?></td>
						<td>
							<img id="image-preview" src="<?php echo $url; ?>" class="device_image">
							<input type="hidden" name="image_attachment_id" id="image_attachment_id" value="<?php echo $cvalue->image; ?>">
						</td>
					   
						
						<td>
							<span class="slidershow_btn_edit" onclick="edit_device_type('<?php echo $slider_id; ?>','<?php echo $cvalue->name; ?>','<?php echo $cvalue->image; ?>','<?php echo $cvalue->timeframe; ?>','<?php echo $cvalue->warranty; ?>');">
								<i class="fas fa-pencil-alt button-primary"></i>
								<input type="hidden" id="<?php echo $slider_id; ?>-dt-desc" value="<?php echo $cvalue->description; ?>">
							</span>
							<span class="sqw_btn_remove" onclick="sqw_remove('sqw_device_type',<?php echo $slider_id; ?>);">
								<i class="fas fa-trash-alt button-primary"></i>
							</span>
						</td>
					</tr>
				<?php
						$i++;
					}
				?>
				</tbody>
			</table>
			<?php
				}

				$my_saved_attachment_post_id = get_option( 'media_selector_attachment_id', 0 );
			?>
			</div>
		<script type="text/javascript">
			$ = jQuery;
			$(document).ready(function ($){
				var file_frame;
				var wp_media_post_id = wp.media.model.settings.post.id;
				var set_to_post_id = '<?php $my_saved_attachment_post_id; ?>';

				$('#upload_image_button').on('click', function( event ){
					event.preventDefault();
					if ( file_frame ) {
						file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
						file_frame.open();
						return;
					} else {
						wp.media.model.settings.post.id = set_to_post_id;
					}

					file_frame = wp.media.frames.file_frame = wp.media({
						title: 'Select a image to upload',
						button: {
							text: 'Use this image',
						},
						library: {
							type: ['image' ]
						},
						multiple: false
					});

					file_frame.on( 'select', function() {
						attachment = file_frame.state().get('selection').first().toJSON();

						if(attachment.type == 'image') {            
							$('.error-message').remove();
							$('.image-preview-wrapper').css('display', 'block');
							$( '#image-preview' ).attr( 'src', attachment.url );
							$( '#image_attachment_id' ).val( attachment.id );
						} else {
							$('.image-preview-wrapper').css('display', 'none');
							$('.image-preview-wrapper').after('<p class="error-message">Please select image file only</p>');
						}

						wp.media.model.settings.post.id = wp_media_post_id;
					});
					
					file_frame.open();
				});

				$( 'a.add_media' ).on( 'click', function() {
					wp.media.model.settings.post.id = wp_media_post_id;
				});
			});
		// WordPress Default Media Selector

		// Open Popup on button click event
		$('.popup-wrapper, .popup-overlay').hide();
		function open_popup() {
			$('body').addClass('modal-open');
			$("#slider_form")[0].reset();
			$("#image-preview").attr('src','');
			$('.popup-title').html('Add Slider');
			$('#device_type_action').val('device_type_add');
			$('#btn_type_submit').val('Add Slider');

			$(".popup-wrapper, .popup-overlay").show();
			$(".popup-wrapper, .popup-overlay").css('visibility','visible');
			$(".popup-wrapper, .popup-overlay").css('opacity','1');
		}

		// Open Edit Popup
		function edit_device_type(id,name,imageid,timeframe,warranty){
			var desc = $('#' + id + '-dt-desc').val();
			$('.popup-title').html('Edit Slider');
			$('#device_type_action').val('device_type_edit');
			$('#btn_type_submit').val('Update');
			$('#slider_id').val(id);
			$('#type_name').val(name);
			image_url(imageid);
			$('#image_attachment_id').val(imageid);
			$(".popup-wrapper, .popup-overlay").show();
			$(".popup-wrapper, .popup-overlay").css('visibility','visible');
			$(".popup-wrapper, .popup-overlay").css('opacity','1');
		}
		</script>
	</div>