<?php
// If this file is called directly, it will abort //
if(!defined('WPINC')){ die; }
?>