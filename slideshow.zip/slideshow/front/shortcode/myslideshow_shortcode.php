<?php 
add_shortcode( 'myslideshow', 'myslideshow_function' );
function myslideshow_function(){
	global $wpdb;
    $slider_tble = $wpdb->prefix."slider_tble";
	ob_start();
	?>
	<link href="<?php echo SLIDESHOW_PLUGIN_DRI_URL; ?>front/inc/css/slideshow.css" rel="stylesheet"> 
	<div class="myslideshow-container">
		<?php
		$type_sql = "SELECT * FROM $slider_tble WHERE status = '1' ";
		$type_result = $wpdb->get_results($type_sql);
		if($type_result) {
			foreach ($type_result as $type_value) {
				$slider_id = $type_value->id;
				if(isset($type_value->image) && !empty($type_value->image)) {
					$imageExist = wp_get_attachment_metadata($type_value->image);
					if(isset($imageExist) && !empty($imageExist)) {
						$url = wp_get_attachment_url($type_value->image);
						if(!empty($url)) {
							$url = $url;
						} else {
							$url = SQW_PLUGIN_PLACEHOLDER_IMAGE_URL;
						}
					} else {
						$url = SQW_PLUGIN_PLACEHOLDER_IMAGE_URL;
					}
				} else {
					$url = SQW_PLUGIN_PLACEHOLDER_IMAGE_URL;
				}
			?>
			<div class="mySlides fade">
				<img src="<?php echo $url; ?>" style="width:100%">
			</div>
			<?php	
				}
			}		
		?>
		<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
		<a class="next" onclick="plusSlides(1)">&#10095;</a>
	</div>
	<br>
	<script src="<?php echo SLIDESHOW_PLUGIN_DRI_URL; ?>front/inc/js/slidershow.js"></script>
	<?php
	return ob_get_clean();
	}
?>